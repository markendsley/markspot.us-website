<?php

session_start();


?>

<?php
$title = "Markspot.us";                  
include "header.php";                 
?>


<!doctype html>
<html>
	<head>
		<title>
			Markspot.us
		</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta name="description" content="Markspot website where I, Mark Endsley, compile all the little projects I've done over the years.">
		<meta name="keywords" content="Markspot, Mark, Endsley, Mark Endsley">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		

		
		<script type="text/javascript">
		
				class player{
				
				constructor(name){
					this.name = name;
					this.score = 0;
				}
						
				}
				
				class question{
					
					constructor(actualQuestion, correctAnswer){
						this.actualQuestion = actualQuestion;
						this.correctAnswer = correctAnswer;
					}
					
				}
				
				
			
				
		
			var numPlayers;
			var players = [];
			var answers = [];
			var questions = [];
			
			
			questions.push(new questions("How many years did it take to build the Golden Gate Bridge?",4));
			
			
		
			function takePlayers(){
				
				numPlayers = document.getElementById("playerNumber").value;
				
				
				document.getElementById("first").style.display = 'none';
				
				document.getElementById("second").style.display = 'block';
				
				if(numPlayers == 5){
					
					document.getElementById("second").innerHTML = 'Player 1 <input type="text" id="name1" value=""> Player 2 <input type="text" id="name2"> Player 3 <input type="text" id="name3"> Player 4 <input type="text" id="name4"> Player 5 <input type="text" id="name5">';
					
				}
				else if(numPlayers == 4){
					
					document.getElementById("second").innerHTML = 'Player 1 <input type="text" id="name1" value=""> Player 2 <input type="text" id="name2"> Player 3 <input type="text" id="name3"> Player 4 <input type="text" id="name4">';

				}
				else if(numPlayers == 3){
					
					document.getElementById("second").innerHTML = 'Player 1 <input type="text" id="name1" value=""> Player 2 <input type="text" id="name2"> Player 3 <input type="text" id="name3">';

				}
				else if(numPlayers == 2){
					
					document.getElementById("second").innerHTML = 'Player 1 <input type="text" id="name1" value=""> Player 2 <input type="text" id="name2"> ';

				}
				else if(numPlayers == 1){
					
					document.getElementById("second").innerHTML = 'Player 1 <input type="text" id="name1" value=""> ';

				}
				
				document.getElementById("third").innerHTML = '<input type="button" id="go" onclick="startGame();"> ';
				
			}
			
			function startGame(){
				
				players = [];
				var b;
				
				
				
				for(i=0;i<numPlayers;i++){
					
					b = i+1;
					var p = document.getElementById("name"+b).value;
					players.push(new player(p));
				}
				
				document.getElementById("second").style.display = 'none'
				document.getElementById("third").style.display = 'none'
				
				
				
				letsDoThis();
				
			}
			
			function letsDoThis(){
				
				document.getElementById("fourth").style.display = 'block';
				
				for(i=0;i<numPlayers;i++)
				{
					var b = i + 1;
					document.getElementById("cancer"+ b).innerHTML = players[i].name + players[i].score + '<input type="number" id="input'+b+'">';
					
				}
				
				document.getElementById("answer").innerHTML = '<input type="button" onclick="">';
			}
			
			function testScores(){
				
				for(i=0;i<numPlayers;i++){
					
					var b = i + 1;
					var testAnswer = document.getElementById("input"+b).value;
					
					
					
					
					
				}
				
				
			}
			

			
			let player1 = new player("Markspot");
			let testQuestion = new question("How many years did it take to build the Golden Gate Bridge?",4);
	
		</script>
		
		
		
	</head>
	<body>
	
	
		<!-- HEADER OF WEBSITE -->


	

	

		<!-- HEADER ENDS -->
		<br>
		<?php
			if(isset($_SESSION['id']))
			{
				echo $_SESSION['uid'] . ' You are now logged in, <a href="logout.php">logout</a>';
			}else
			{
				echo ' <form action="signin.php" method="POST" align="right" style="display:inline"><button type="submit" class="button2">Sign in / Sign Up</button></form>';
			}
		?>
		<br>
		<br/>
		<div class="bordertwo">
		<!-- STUFF GOES IN HERE -->
		<br><br>
		

		<span id="first">
		<form>
		
		Number of Players
		<input type="number" id="playerNumber">
		<input type="button" onclick="takePlayers()">
		</form>
		</span>
		
		
		
		<form>
		<span id="second">

		</span>
		<span id="third">
		
		</span>
		</form>
		
		<span id="fourth">
		
		
		
		
	
				
				<span id="cancer1">
				
				
				
				
				</span>
				
				
				<span id="cancer2">
				
				
				
				
				</span>
				
				
				<span id="cancer3">
				
				
				
				
				</span>
				
				
				<span id="cancer4">
				
				
				
				
				</span>
				
				
				<span id="cancer5">
				
				
				
				
				</span><br><br>
				<span id="answer">
				
				
				
				
				</span>
				
			
			
		
		</span>
		
		
				<p id="demo"></p>

	
		

		
		
		
		
		
	<br/><br/><br/><br/><br/><br/><br/><br/>
	
	
	
		<!-- STUFF STOPS HERE -->
		</div>
		<font size="2"><center><br/><br/>Markspot Website<br/>Thank you for visiting my website | Site by Mark Endsley</center></font>
	
	
	</body>
</html>
		