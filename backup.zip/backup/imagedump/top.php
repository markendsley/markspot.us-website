
	
	<div class="border">
		<br/>
		<img style="float:center;" src="images/banner.png"><a href="https://discord.gg/c6vrBtV"><img align="right" src="images/discord.png"></a>&nbps;<a href="https://www.linkedin.com/in/mark-endsley-7b7024b3"><img align="right" src="images/linkedin.png"></a>&nbps;
		<br/>
		<br/>
		
	
				<img id="slider" class="scalable" src="images/slider.png" alt="Markspot">
				
	
		
		
		
		
		<br/>
		<br/>
		
		
	
		<ul>
			<li><a href="index.php"><img src="images/home.png"></a></li>
			<li><a href="news.php"><img src="images/news.png"></a></li>
			<li><a href="videos.php"><img src="images/videos.png"></a></li>
			<li><a href="code.php"><img src="images/code.png"></a></li>
			<li><a href="pages.php"><img src="images/pages.png"></a></li>
			<li><a href="images.php"><img src="images/images.png"></a></li>
			<li><a href="docs.php"><img src="images/docs.png"></a></li>
			<li style="float:right"><a class="active" href="about.php"><img src="images/about.png"></a></li>
		</ul>
		</div>