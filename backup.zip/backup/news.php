<?php

session_start();


?>

<?php
$title = "Markspot.us";                  
include "header.php";                 
?>
<!doctype html>
<html>
	<head>
		<title>
			Markspot.us
		</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		
		
		

		<script type="text/javascript">
		
		var images = [];
		images[0] = "images/slider.png";
		images[1] = "images/slider2.png";
		images[2] = "images/slider3.png";
		var i = 0;
		
			function change(){
				
				if(i==0){
					var image = document.getElementById('slider');
					image.src = images[i];
					i++;
				}
				else if(i==1)
				{
					var image = document.getElementById('slider');
					image.src = images[i];
					i++;
				}
				else if(i==2)
				{
					var image = document.getElementById('slider');
					image.src = images[i];
					i=0;
				}
			}

			setInterval('change()',13000);
		</script>

		
		
		
	</head>
	<body>
	
	
	
	
	

	
	
	
	
	
	
	
	
		<!-- HEADER OF WEBSITE -->
	
<?php             
include "top.php";                 
?>
	
		<!-- HEADER ENDS -->
		<br/>
		<div class="bordertwo">
		<!-- STUFF GOES IN HERE -->
		<h1>News</h1>
		<br/>
		<center>
		
		<div class="newsbox">
		<h3><center>9.16.2017</center></h3>
		For a number of reasons, I find what has happened with Equifax to be absolutely stunning, and not in a good way. I don’t place any blame on the IT staff as I’ve heard they tried to prevent this calamity. I have yet to be able to confirm they were storing passwords in plaintext. On this website, none of your pertinent information is even asked for. Even with that, your password is NOT stored in plaintext. Even as a mere IT student I understand that is simply not acceptable. A great programmer once said that if we do not regulate this industry ourselves, we will be regulated by the government. I would say most of us don’t want that, but at this point I am not sure. If we still have the opportunity to self-regulate, it is quickly fading.
		
		<br/>
		</div>
		<br/>
		
		
		
		<div class="newsbox">
		<h3><center>8.19.2017</center></h3>
		Added Discord Server and Linked in to top.
		
		<br/>
		</div>
		<br/>
		
		
		
		<div class="newsbox">
		<h3><center>8.17.2017</center></h3>
		Added a comment section to the homepage, feel free to leave comments but please nothing vulgar, thank you!
		
		<br/>
		</div>
		<br/>
		
		
		
		
		
		<div class="newsbox">
		<h3><center>8.10.2017</center></h3>
		Added a log in system. Feel free to create an account. Keep in mind it is possible that the login system will eventually be overhauled, but in the meantime I will be adding more functionality to it.
		
		<br/>
		</div>
		<br/>
		
		
		
		
		<div class="newsbox">
		<h3><center>7.28.2017</center></h3>
		Added PHP Dice to pages.
		
		<br/>
		</div>
		<br/>
		
		
		
		
		<div class="newsbox">
		<h3><center>7.25.2017</center></h3>
		Added Cribbage game from school project and updated descriptions for some entries. Also added image of baby ducks and got FTP working on the server.
		
		<br/>
		</div>
		<br/>
		
		
		<div class="newsbox">
		<h3><center>6.29.2017</center></h3>
		Updated Age Counter and Updated GPA.
		
		<br/>
		</div>
		<br/>
		
		
		
		
		<div class="newsbox">
		<h3><center>5.5.2017</center></h3>
		Added an "About" section. Its a short Bio on me. Spring semester is over and its looking like I did pretty well. Have a happy summer.
		
		<br/>
		</div>
		<br/>
		
		
		
		<div class="newsbox">
		<h3><center>4.20.2017</center></h3>
	
		So I'm starting this website running off of a server in my apartment. I'm planning on compiling all the work I've done in programming and other technology related things. I've uploaded a lot of content already, and as I create new things I will continue to add them.
		<br/>
		</div>
		
		</center>
	<br/><br/><br/><br/>
	
	
	
	
	
	
		<!-- STUFF STOPS HERE -->
		</div>
		<font size="2"><center><br/><br/>Markspot Website<br/>Thank you for visiting my website | Site by Mark Endsley</center></font>
	
		
		
	</body>
	

	
	
</html>
		
		
		
		
		
		

		