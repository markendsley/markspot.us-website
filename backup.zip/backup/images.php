<?php

session_start();


?>

<?php
$title = "Markspot.us";                  
include "header.php";                 
?>
<!doctype html>
<html>
	<head>
		<title>
			Markspot.us
		</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		
		
		<script type="text/javascript">
		
		var images = [];
		images[0] = "images/slider.png";
		images[1] = "images/slider2.png";
		images[2] = "images/slider3.png";
		var i = 0;
		
			function change(){
				
				if(i==0){
					var image = document.getElementById('slider');
					image.src = images[i];
					i++;
				}
				else if(i==1)
				{
					var image = document.getElementById('slider');
					image.src = images[i];
					i++;
				}
				else if(i==2)
				{
					var image = document.getElementById('slider');
					image.src = images[i];
					i=0;
				}
			}

			setInterval('change()',13000);
		</script>
		
		
	</head>
	<body>
	
	
		<!-- HEADER OF WEBSITE -->
	
	
<?php             
include "top.php";                 
?>
		<!-- HEADER ENDS -->
		<br/>
		<div class="bordertwo">
		<!-- STUFF GOES IN HERE -->
		
		<h2>Baby Ducks Outside My Apartment</h2>
		
		<center>
		<a href="images/ducks.jpg"><img src="images/ducks.jpg" height="7%" width="7%"></a>
		<br>
		<div class="newsbox">
		
	
		
		Just a picture of the baby ducks that were born outside my apartment.
		<br/><br/>
		<center><a href="images/ducks.jpg">JPG File</a>
		</div>
		</center>
		
		
			<br/>
			<br/>
		
		
		
		<h2>Politics Infograph</h2>
		
		<center>
		<a href="images/infov6.jpg"><img src="images/infov6.jpg" height="7%" width="7%"></a>
		<br>
		<div class="newsbox">
		
		
		A cool politics infograph I made back in my Digital Design class. It is a bit outdated, but I think its still pretty good.
		<br/><br/>
		<center><a href="downloads/infov6.ai">Adobe Illustrator File</a>
		</div>
		</center>
		
		
	<br/><br/><br/><br/>
	
	
	
		<!-- STUFF STOPS HERE -->
		</div>
		<font size="2"><center><br/><br/>Markspot Website<br/>Thank you for visiting my website | Site by Mark Endsley</center></font>
	
	
	</body>
</html>
		