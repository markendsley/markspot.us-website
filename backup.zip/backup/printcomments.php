<?php 

$connect = mysqli_connect('localhost','root','','comments');

if(!$connect)
{
	die("Connection failed: ".mysqli_connect_error());
}

$query = "Select * FROM usercomments ORDER BY date DESC LIMIT 999999";
$result = $connect->query($query);

while($row = mysqli_fetch_assoc($result))
{
	
	echo '<div class="commentsbox" style="color: black;"><table width = "100%"><tr><td width="10%"><font color="black">' . $row['uid'] . '</font></td><td width="10%"><font color="black"> &nbsp;&nbsp;' . $row['date'] . '</font></td><td width="80%"><font color="black"> &nbsp;&nbsp;' . $row['message'] . '</font></td></tr></table></div><br>
	
	
	';
	
}


?>