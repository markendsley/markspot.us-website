<?php


$conn = mysqli_connect('localhost','root','','images');

if(!$conn)
{
	die("Connection failed: ".mysqli_connect_error());
}




?>