<html>
    <head>
        <meta http-equiv="refresh" content="3;url=http://markspot.us#commentline" />
		<link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <br>
		<br/>
		<div class="bordertwo">
		<!-- STUFF GOES IN HERE -->
		
		

		
		
		
		
		
		

		<br/><br/>
		<img src="images/redirecting.png" class="scalable">
		<br/><br/><br/>
		Thank You For Posting.
		<br/><br/>
		

	<br/><br/><br/><br/><br/><br/><br/><br/>
	
	
	
		<!-- STUFF STOPS HERE -->
		</div>
    </body>
</html>