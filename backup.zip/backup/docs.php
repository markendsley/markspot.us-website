<?php

session_start();


?>

<?php
$title = "Markspot.us";                  
include "header.php";                 
?>
<!doctype html>
<html>
	<head>
		<title>
			Markspot.us
		</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
	
	
		<!-- HEADER OF WEBSITE -->
	
	
		<div class="border">
		<br/>
		<img src="images/banner.png">
		<br/>
		<br/>
		<img class="scalable" src="images/slider.png">
		<br/>
		<br/>
		
		
	
		<ul>
			<li><a href="index.php"><img src="images/home.png"></a></li>
			<li><a href="news.php"><img src="images/news.png"></a></li>
			<li><a href="videos.php"><img src="images/videos.png"></a></li>
			<li><a href="code.php"><img src="images/code.png"></a></li>
			<li><a href="pages.php"><img src="images/pages.png"></a></li>
			<li><a href="images.php"><img src="images/images.png"></a></li>
			<li><a href="docs.php"><img src="images/docs.png"></a></li>
			<li style="float:right"><a class="active" href="about.html"><img src="images/about.png"></a></li>
		</ul>
		</div>
		<!-- HEADER ENDS -->
		<br/>
		<div class="bordertwo">
		<!-- STUFF GOES IN HERE -->
		
		<h2>Build Your Own Computer Instructions</h2>
		
		Complete instruction manual that I wrote on how to build your own desktop computer.<br/><br/>
		<a href="downloads/computerinstructions.pdf">PDF File</a>
		<br/><br/><br/>
		
		
		
	<br/><br/><br/><br/>
	
	
	
		<!-- STUFF STOPS HERE -->
		</div>
		<font size="2"><center><br/><br/>Markspot Website<br/>Thank you for visiting my website | Site by Mark Endsley</center></font>
	
	
	</body>
</html>
		