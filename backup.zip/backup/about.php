<?php

session_start();


?>

<?php
$title = "Markspot.us";                  
include "header.php";                 
?>
<!doctype html>
<html>
	<head>
		<title>
			Markspot.us
		</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
	
	
		<!-- HEADER OF WEBSITE -->
	
	
<?php             
include "top.php";                 
?>
		<!-- HEADER ENDS -->
		<br/>
		<div class="bordertwo">
		<!-- STUFF GOES IN HERE -->
		
		<br/>
		<br/>
		<h2>Hi, My Name is Mark Endsley</h2>
		<br/>
		<center>
		<img src="images/me2.png" height="30% width="30%">
		
		<br/><br/>
		
		<div class="newsbox">
		
		&nbsp;&nbsp;&nbsp;&nbsp;I'm an IT Major at University of Central Florida. I've been doing SEO work for the past year and a half now. 
		I have a 3.48 GPA and I do particularly well in programming classes. Beyond programming and coding I enjoy graphic design, web design,
		game design, computer building, and pretty much anything else related to computers. I also enjoy keeping up with current events, and having
		good times with friends and family.
		
		</div>
		</center>
	<br/><br/><br/><br/><br/>
	
	
	
		<!-- STUFF STOPS HERE -->
		</div>
		<font size="2"><center><br/><br/>Markspot Website<br/>Thank you for visiting my website | Site by Mark Endsley</center></font>
	
	
	</body>
</html>
		