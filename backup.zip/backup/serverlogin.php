<?php


$user = 'root';
$pass = '';
$db = 'Markspot';

$db = new mysqli('localhost',$user,$pass,$db) or die("Unable to connect sad...");

?>