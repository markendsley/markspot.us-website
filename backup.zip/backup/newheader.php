
<?php

echo'<nav class="navbar navbar-default">
<div class="container-fluid">
<div class="navbar-header">
</div>
</div>

</nav>'
			
?>

