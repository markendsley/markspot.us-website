<?php

session_start();


?>

<?php
$title = "Markspot.us";                  
include "header.php";                 
?>
<!doctype html>
<html>
	<head>
		<title>
			Markspot.us
		</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		
		<script type="text/javascript">
		
		var images = [];
		images[0] = "images/slider.png";
		images[1] = "images/slider2.png";
		images[2] = "images/slider3.png";
		var i = 0;
		
			function change(){
				
				if(i==0){
					var image = document.getElementById('slider');
					image.src = images[i];
					i++;
				}
				else if(i==1)
				{
					var image = document.getElementById('slider');
					image.src = images[i];
					i++;
				}
				else if(i==2)
				{
					var image = document.getElementById('slider');
					image.src = images[i];
					i=0;
				}
			}

			setInterval('change()',13000);
		</script>
		
		
	</head>
	<body>
	
	
		<!-- HEADER OF WEBSITE -->
	
	
<?php             
include "top.php";                 
?>
		<!-- HEADER ENDS -->
		<br/>
		<div class="bordertwo">
		<!-- STUFF GOES IN HERE -->
		
		<h2>Cribbage Demo</h2>
		
		An android app I wrote for a project at school that simulates one turn of the game Cribbage. <br/>
		The game comes complete with a user interface and graphics for the card game. <br/>
		<br/>
		
		<a href="https://github.com/markendsley/Cribbage/tree/master/app">Github Link</a><br/><br/>
		
		<br/><br/><br/>
		
		
		<h2>Bogo Sort</h2>
		
		Bogo sort is the worst sorting algorythm ever created by man. Its method is akin to throwing a <br/>
		deck of cards against a wall and picking them up until you happen to get them in order. To run <br/>
		you must give it a one integer argument that will be the number of array slots to sort.<br/><br/>
		
		<a href="downloads/bogo.c">Source File</a><br/><br/>
		<a href="downloads/bogo.exe">EXE File</a>
		<br/><br/><br/>
		
		<h2>Memory Destructor</h2>
		
		<center><img src="images/donot.png"></center>
		
		Memory Destructor will eat your computers memory until it crashes. WARNING RUNNING THIS PROGRAM <br/>
		WILL CRASH YOUR COMPUTER!<br/><br/>
		<a href="downloads/memorydestructor.c">Source File</a><br/><br/>
		<a href="downloads/memorydestructor.exe">EXE File</a>
		<br/><br/><br/>
		
	<br/><br/><br/><br/>
	
	
	
		<!-- STUFF STOPS HERE -->
		</div>
		<font size="2"><center><br/><br/>Markspot Website<br/>Thank you for visiting my website | Site by Mark Endsley</center></font>
	
	
	</body>
</html>
		