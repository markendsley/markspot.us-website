<?php

session_start();


?>

<?php
$title = "Markspot.us";                  
include "header.php";                 
?>


<!doctype html>
<html>
	<head>
		<title>
			Markspot.us
		</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<meta name="description" content="Markspot website where I, Mark Endsley, compile all the little projects I've done over the years.">
		<meta name="keywords" content="Markspot, Mark, Endsley, Mark Endsley">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		

		
		<script type="text/javascript">
		
		var images = [];
		images[0] = "images/slider.png";
		images[1] = "images/slider2.png";
		images[2] = "images/slider3.png";
		var i = 0;
		
			function change(){
				
				if(i==0){
					var image = document.getElementById('slider');
					image.src = images[i];
					i++;
				}
				else if(i==1)
				{
					var image = document.getElementById('slider');
					image.src = images[i];
					i++;
				}
				else if(i==2)
				{
					var image = document.getElementById('slider');
					image.src = images[i];
					i=0;
				}
			}

			setInterval('change()',13000);
		</script>
		
		
		
	</head>
	<body>
	
	
		<!-- HEADER OF WEBSITE -->
	

<?php             
include "top.php";                 
?>
		<!-- HEADER ENDS -->
		<br>
		<?php
			if(isset($_SESSION['id']))
			{
				echo $_SESSION['uid'] . ' You are now logged in, <a href="logout.php">logout</a>';
			}else
			{
				echo ' <form action="signin.php" method="POST" align="right" style="display:inline"><button type="submit" class="button2">Sign in / Sign Up</button></form>';
			}
		?>
		<br>
		<br/>
		<div class="bordertwo">
		<!-- STUFF GOES IN HERE -->
		
		

		
		
		
		
		
		

		<br/><br/>
		<img class="scalable" src="images/welcome.png" >
		<br/><br/><br/>
		<p class=>My name is Mark Endsley, I'm an IT major at the University of Central Florida. Here I compile<br/> all the work I've done over my life and career. Feel free to check out anything I've posted here.</p>
		<br/><br/>
		
		<a href="news.php"><img class="flick" src="images/newsbutton.png"></a>
		<a href="videos.php"><img class="flick" src="images/videosbutton.png"></a>
		<a href="code.php"><img class="flick" src="images/codebutton.png"></a>
		<a href="pages.php"><img class="flick" src="images/pagesbutton.png"></a><br/>
		<a href="images.php"><img class="flick" src="images/imagesbutton.png"></a>
		<a href="docs.php"><img class="flick" src="images/docsbutton.png"></a>
		<a href="about.php"><img class="flick" src="images/aboutbutton.png"></a>
		
		
		
				<br/><br/><br/><br/>
		
		<a name="commentline"><img src="/images/comments.png"></a><br><br>
		
		<?php
		
		if(isset($_SESSION['id']))
		{
			echo'<form id="comment" name="comment" action="submitcomment.php" method="POST">
		<textarea class="styled" rows="4" cols="50" id="addedcomment" width="60%" name="addedcomment" style="height=500px;" required></textarea>
		<br><button type="submit" class="button">Submit</button>
		</form>';
		}
		

		
		?>
		
		<font color="black">
		<center>
		<?php include('printcomments.php');?>
		</center>
		</font>
		
		
		
		
	<br/><br/><br/><br/><br/><br/><br/><br/>
	
	
	
		<!-- STUFF STOPS HERE -->
		</div>
		<font size="2"><center><br/><br/>Markspot Website<br/>Thank you for visiting my website | Site by Mark Endsley</center></font>
	
	
	</body>
</html>
		