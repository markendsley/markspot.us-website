<html>
    <head>
        <meta http-equiv="refresh" content="5;url=http://markspot.us" />
		<link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <br>
		<br/>
		<div class="bordertwo">
		<!-- STUFF GOES IN HERE -->
		
		

		
		
		
		
		
		

		<br/><br/>
		<img src="images/redirecting.png" class="scalable">
		<br/><br/><br/>
		You are now signed up, you will be redirected to the home page where you can now sign in.
		<br/><br/>
		

	<br/><br/><br/><br/><br/><br/><br/><br/>
	
	
	
		<!-- STUFF STOPS HERE -->
		</div>
    </body>
</html>