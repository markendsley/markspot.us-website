<?php

session_start();


?>

<?php
$title = "Markspot.us";                  
include "header.php";                 
?>
<!doctype html>
<html>
	<head>
		<title>
			Markspot.us
		</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		
		<script type="text/javascript">
		
		var images = [];
		images[0] = "images/slider.png";
		images[1] = "images/slider2.png";
		images[2] = "images/slider3.png";
		var i = 0;
		
			function change(){
				
				if(i==0){
					var image = document.getElementById('slider');
					image.src = images[i];
					i++;
				}
				else if(i==1)
				{
					var image = document.getElementById('slider');
					image.src = images[i];
					i++;
				}
				else if(i==2)
				{
					var image = document.getElementById('slider');
					image.src = images[i];
					i=0;
				}
			}

			setInterval('change()',13000);
		</script>
		
		
	</head>
	<body>
	
	
		<!-- HEADER OF WEBSITE -->
<?php             
include "top.php";                 
?>
		<!-- HEADER ENDS -->
		<br/>
		<div class="bordertwo">
		<!-- STUFF GOES IN HERE -->
		<br/>
		
		<div style="background-color:gold" margin-left="30%";margin-right="30%"><h1>Programming Videos</hi></div>
		<br/>
		
		<h2>How To Use Jbaci</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/_mAiXPIOI6Q" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		
		<div style="background-color:gold" margin-left="30%";margin-right="30%"><h1>C Programming Videos</hi></div>
		<br/>
		
		<h2>Printf in C</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/HQs7VqgR9vg" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		<h2>Arithmetic in C</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/6rzFUKaLKVc" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		<h2>How To Print Variables in C</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/826fTEus3Ko" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		<h2>If, Else If, Else in C.</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/hJqDsjwwVso" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		<h2>Switch Statements in C</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/Hu8lSKbtrLo" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		<h2>Loops in C</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/zkIb-nIlC38" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		<h2>How to Write a Basic Function in C</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/A5RilM4JV1g" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		<h2>How Pointers Work in C</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/tIIFetrGAdc" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		<h2>How to Use The Debugger in CodeBlocks.</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/h_r5ZfETRZQ" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		<h2>How To Dynamically Allocate a 2D Array in C</h2>
		<br/>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/t72BzxMAQKs" frameborder="0" allowfullscreen></iframe>
		<br/>
		<br/>
		
		<br/>

	<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
	
	
	
		<!-- STUFF STOPS HERE -->
		</div>
		<font size="2"><center><br/><br/>Markspot Website<br/>Thank you for visiting my website | Site by Mark Endsley</center></font>
	
	
	</body>
</html>
		